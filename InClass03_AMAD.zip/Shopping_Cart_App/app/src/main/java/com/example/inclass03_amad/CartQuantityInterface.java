package com.example.inclass03_amad;

public interface CartQuantityInterface {
    public void getTotal(Product product,int position);
}
