package com.example.inclass03_amad;

public interface AddToCartInterface {
    public void addToCart(Product product);
    public void removeFromCart(Product product);
}
