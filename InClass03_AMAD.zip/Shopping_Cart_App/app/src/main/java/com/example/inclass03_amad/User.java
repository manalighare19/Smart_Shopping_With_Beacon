package com.example.inclass03_amad;

import java.io.Serializable;

public class User implements Serializable {
    String userID;
    String firstname;
    String lastname;
    String email;
    String address;
}

